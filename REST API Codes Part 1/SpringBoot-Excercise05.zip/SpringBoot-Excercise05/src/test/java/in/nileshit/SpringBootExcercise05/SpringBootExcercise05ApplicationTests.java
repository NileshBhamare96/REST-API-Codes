package in.nileshit.SpringBootExcercise05;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootExcercise05ApplicationTests {

	@Test
	void contextLoads() {
	}

}
